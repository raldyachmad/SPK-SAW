<img src="{{ asset('logo.svg') }}" alt="Logo SPK Skripsi" {{ $attributes }}>
